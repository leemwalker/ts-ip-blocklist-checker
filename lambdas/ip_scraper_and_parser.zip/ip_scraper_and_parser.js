"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
var cross_fetch_1 = require("cross-fetch");
var fs_1 = require("fs");
var csv_parse_1 = require("csv-parse");
var createCsvWriter = require('csv-writer').createObjectCsvWriter;
var csvWriterOne = createCsvWriter({
    path: 'ip_addresses_lvl1.csv',
    header: [
        { id: 'address', title: 'Address' },
        { id: 'level', title: 'Level' }
    ]
});
var csvWriterTwo = createCsvWriter({
    path: 'ip_addresses_lvl2.csv',
    header: [
        { id: 'address', title: 'Address' },
        { id: 'level', title: 'Level' }
    ]
});
var csvWriterThree = createCsvWriter({
    path: 'ip_addresses_lvl3.csv',
    header: [
        { id: 'address', title: 'Address' },
        { id: 'level', title: 'Level' }
    ]
});
var BaseURL = "https://api.github.com/repositories/35515847/git/trees/master?recursive=1";
function pullFromRepo(url) {
    return __awaiter(this, void 0, void 0, function () {
        var response, data, result;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, (0, cross_fetch_1["default"])(url)];
                case 1:
                    response = _a.sent();
                    if (!response.ok) {
                        throw new Error(response.statusText);
                    }
                    return [4 /*yield*/, response.json()];
                case 2:
                    data = _a.sent();
                    result = JSON.parse(JSON.stringify(data));
                    return [2 /*return*/, result];
            }
        });
    });
}
function chainResults(BaseURL) {
    return __awaiter(this, void 0, void 0, function () {
        var fileList, _a, _b, _c, _d, ipList, _i, _e, file, currentFile, _f, _g, _h, _j, fileContents, fileLevel;
        return __generator(this, function (_k) {
            switch (_k.label) {
                case 0:
                    _b = (_a = JSON).parse;
                    _d = (_c = JSON).stringify;
                    return [4 /*yield*/, pullFromRepo(BaseURL)];
                case 1:
                    fileList = _b.apply(_a, [_d.apply(_c, [_k.sent()])]);
                    _i = 0, _e = fileList["tree"];
                    _k.label = 2;
                case 2:
                    if (!(_i < _e.length)) return [3 /*break*/, 6];
                    file = _e[_i];
                    if (!(file["path"].endsWith(".ipset") || file["path"].endsWith(".netset"))) return [3 /*break*/, 5];
                    _g = (_f = JSON).parse;
                    _j = (_h = JSON).stringify;
                    return [4 /*yield*/, pullFromRepo(file["url"])];
                case 3:
                    currentFile = _g.apply(_f, [_j.apply(_h, [_k.sent()])]);
                    fileContents = Buffer.from(currentFile["content"], currentFile["encoding"]).toString('utf-8');
                    fileLevel = checkLevel(file["path"]);
                    ipList = cleanFileContents(fileContents);
                    return [4 /*yield*/, writeToCsv(ipList, fileLevel)];
                case 4:
                    _k.sent();
                    _k.label = 5;
                case 5:
                    _i++;
                    return [3 /*break*/, 2];
                case 6:
                    cleanFiles('ip_addresses_lvl1.csv');
                    cleanFiles('ip_addresses_lvl2.csv');
                    cleanFiles('ip_addresses_lvl3.csv');
                    return [2 /*return*/];
            }
        });
    });
}
function checkLevel(filename) {
    var levelOne = ["feodo", "palevo", "sslbl", "zeus_badips", "dshield", "spamhaus_drop", "spamhaus_edrop", "bogons", "fullbogons"];
    var levelTwo = ["openbl", "blocklist_de", "zeus"];
    for (var i = 0; i < levelOne.length; i++) {
        if (filename.indexOf(levelOne[i]) > -1) {
            console.log("This is a level 1 IP Blocklist");
            return "1";
        }
    }
    for (var i = 0; i < levelTwo.length; i++) {
        if (filename.indexOf(levelTwo[i]) > -1) {
            console.log("This is a level 2 IP Blocklist");
            return "2";
        }
    }
    console.log("This is a level 3 IP Blocklist");
    return "3";
}
function cleanFileContents(fileContents) {
    var unparsedIpList = [];
    for (var _i = 0, _a = fileContents.split(/\r\n|\r|\n/); _i < _a.length; _i++) {
        var line = _a[_i];
        if (!line.startsWith("#")) {
            unparsedIpList.push(line);
        }
    }
    return checkForDuplicateIps(unparsedIpList);
}
function checkForDuplicateIps(unparsedIpList) {
    return new Set(unparsedIpList);
}
// Add another function here that validates the IPs, ensuring the format 
// ranges from 1.0.0.1 to 255.255.255.255
function writeToCsv(ipList, ipLevel) {
    return __awaiter(this, void 0, void 0, function () {
        var ipsAndLevel, _i, _a, ip, ipAndLevel;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    ipsAndLevel = [];
                    for (_i = 0, _a = ipList.values(); _i < _a.length; _i++) {
                        ip = _a[_i];
                        ipAndLevel = { address: ip, level: ipLevel };
                        ipsAndLevel.push(ipAndLevel);
                    }
                    if (!(ipLevel == "1")) return [3 /*break*/, 2];
                    return [4 /*yield*/, csvWriterOne.writeRecords(ipsAndLevel)
                            .then(function () {
                            console.log('...Done writing to ip_addresses_lvl1.csv');
                        })];
                case 1:
                    _b.sent();
                    _b.label = 2;
                case 2:
                    if (!(ipLevel == "2")) return [3 /*break*/, 4];
                    return [4 /*yield*/, csvWriterTwo.writeRecords(ipsAndLevel)
                            .then(function () {
                            console.log('...Done writing to ip_addresses_lvl2.csv');
                        })];
                case 3:
                    _b.sent();
                    _b.label = 4;
                case 4:
                    if (!(ipLevel == "3")) return [3 /*break*/, 6];
                    return [4 /*yield*/, csvWriterThree.writeRecords(ipsAndLevel)
                            .then(function () {
                            console.log('...Done writing to ip_addresses_lvl3.csv');
                        })];
                case 5:
                    _b.sent();
                    _b.label = 6;
                case 6: return [2 /*return*/];
            }
        });
    });
}
function pullAddressesFromCSV(csvFile) {
    return __awaiter(this, void 0, void 0, function () {
        var ipAddresses;
        return __generator(this, function (_a) {
            ipAddresses = [];
            return [2 /*return*/, new Promise(function (resolve, reject) {
                    fs_1["default"].createReadStream(csvFile)
                        .pipe((0, csv_parse_1["default"])({ delimiter: ',', columns: true }))
                        .on('error', function (error) { return (error); })
                        .on('data', function (row) { return ipAddresses.push(row['Address']); })
                        .on('end', function () {
                        resolve(ipAddresses);
                    });
                })];
        });
    });
}
function cleanFiles(csvFile) {
    return __awaiter(this, void 0, void 0, function () {
        var unparsedIpList, parsedIpList;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, pullAddressesFromCSV(csvFile)];
                case 1:
                    unparsedIpList = _a.sent();
                    parsedIpList = checkForDuplicateIps(unparsedIpList);
                    if (csvFile == 'ip_addresses_lvl1.csv') {
                        fs_1["default"].unlinkSync(csvFile);
                        csvWriterOne.writeRecords(parsedIpList);
                        pullAddressesFromCSV(csvFile);
                    }
                    if (csvFile == 'ip_addresses_lvl2.csv') {
                        fs_1["default"].unlinkSync(csvFile);
                        csvWriterTwo.writeRecords(parsedIpList);
                        pullAddressesFromCSV(csvFile);
                    }
                    if (csvFile == 'ip_addresses_lvl3.csv') {
                        fs_1["default"].unlinkSync(csvFile);
                        csvWriterThree.writeRecords(parsedIpList);
                        pullAddressesFromCSV(csvFile);
                    }
                    return [2 /*return*/];
            }
        });
    });
}
exports.myHandler = function () {
    chainResults(BaseURL);
};
// Write the csv files to the s3 bucket
